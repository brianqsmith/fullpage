(() => {
  if (globalThis.__fullpage) return;
  let session = null;
  const delay = ms => new Promise(r => setTimeout(r, ms));
  function size() {
    const d = document.documentElement, b = document.body;
    return {width: Math.max(d.scrollWidth, b?.scrollWidth || 0, d.clientWidth), height: Math.max(d.scrollHeight, b?.scrollHeight || 0, d.clientHeight), vw: d.clientWidth, vh: d.clientHeight, iw: innerWidth, ih: innerHeight, x: scrollX, y: scrollY};
  }
  function restore() {
    if (!session) return;
    const s = session; session = null;
    clearTimeout(s.timer);
    s.style.remove();
    for (const [el, value, priority] of s.hidden) {
      if (value) el.style.setProperty('visibility', value, priority); else el.style.removeProperty('visibility');
    }
    window.scrollTo({left: s.x, top: s.y, behavior: 'instant'});
  }
  function watchdog() { clearTimeout(session.timer); session.timer = setTimeout(restore, 120000); }
  async function handle(m) {
    if (m.type !== 'fullpage-capture') return;
    if (m.action === 'restore') { restore(); return true; }
    if (m.action === 'start') {
      restore();
      const style = document.createElement('style');
      style.textContent = 'html{scrollbar-width:none!important}html,body,*{scroll-behavior:auto!important;scroll-snap-type:none!important;overflow-anchor:none!important}*{animation-play-state:paused!important;transition:none!important}';
      session = {x: scrollX, y: scrollY, style, hidden: [], timer: null, fixed: []};
      document.documentElement.append(style);
      watchdog();
      return size();
    }
    if (!session) throw new Error('The page changed. Start a new capture.');
    watchdog();
    if (m.action === 'prepare') {
      session.fixed = [...document.querySelectorAll('*')].filter(el => ['fixed', 'sticky'].includes(getComputedStyle(el).position));
      return size();
    }
    if (m.action === 'scroll') {
      if (m.hideFixed) {
        for (const el of session.fixed) {
          if (session.hidden.some(entry => entry[0] === el)) continue;
          // Only suppress currently pinned sticky elements; preserve other content in normal flow.
          const css = getComputedStyle(el), rect = el.getBoundingClientRect();
          if (css.position === 'fixed' || (css.position === 'sticky' && ((css.top !== 'auto' && rect.top <= parseFloat(css.top) + 1) || (css.bottom !== 'auto' && rect.bottom >= innerHeight - parseFloat(css.bottom) - 1)))) {
            session.hidden.push([el, el.style.getPropertyValue('visibility'), el.style.getPropertyPriority('visibility')]);
            el.style.setProperty('visibility', 'hidden', 'important');
          }
        }
      }
      window.scrollTo({left: m.x, top: m.y, behavior: 'instant'});
      await delay(m.pause);
      if (m.waitImages) {
        const imgs = [...document.images].filter(img => { const r = img.getBoundingClientRect(); return !img.complete && r.bottom > 0 && r.top < innerHeight && r.right > 0 && r.left < innerWidth; });
        await Promise.all(imgs.map(img => new Promise(resolve => {
          const done = () => { clearTimeout(timer); img.removeEventListener('load', done); img.removeEventListener('error', done); resolve(); };
          const timer = setTimeout(done, 4000);
          img.addEventListener('load', done, {once: true}); img.addEventListener('error', done, {once: true});
        })));
        if (document.fonts) await Promise.race([document.fonts.ready, delay(1000)]);
      }
      await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));
      return size();
    }
    return size();
  }
  globalThis.__fullpage = true;
  browser.runtime.onMessage.addListener(handle);
  addEventListener('pagehide', restore);
})();
